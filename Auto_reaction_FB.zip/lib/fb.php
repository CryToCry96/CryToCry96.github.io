<?php

error_reporting(0); #disable gender error while react page status
ini_set("default_charset", 'utf-8'); //fix Vietnamese name's

class Reaction
{
    
    function __construct()
    {
        //
    }
    
    ////////////// [alternatif file_get_contents] ///////////////
    private function url_get_contents($Url)
    {
        if (!function_exists('curl_init')) {
            die('CURL is not installed!');
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $Url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        $output = curl_exec($ch);
        curl_close($ch);
        return $output;
    }
    /////////////////////////////////////////////////////////////
    
    private function fetch_value($str, $find_start, $find_end)
    {
        $start = strpos($str, $find_start);
        if ($start === false) {
            return "";
        }
        $length = strlen($find_start);
        $end    = strpos(substr($str, $start + $length), $find_end);
        return trim(substr($str, $start + $length, $end));
    }
    
    private function curl($url = '', $var = '', $echo = '', $ref = '', $header = false)
    {
        global $config, $sock;
        $curl = curl_init($url);
        curl_setopt($curl, CURLOPT_NOBODY, $header);
        curl_setopt($curl, CURLOPT_TIMEOUT, 150);
        curl_setopt($curl, CURLOPT_USERAGENT, 'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:53.0) Gecko/20100101 Firefox/53.0');
        if ($var) {
            curl_setopt($curl, CURLOPT_POST, true);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $var);
        }
        curl_setopt($curl, CURLOPT_COOKIEFILE, $config['cookie_file']);
        curl_setopt($curl, CURLOPT_COOKIEJAR, $config['cookie_file']);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, 0);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($curl);
        curl_close($curl);
        return $result;
    }
    
    private function gender_check($userid, $token)
    {
        $gen_url     = 'https://graph.facebook.com/' . $userid . '?access_token=' . $token;
        $gen_data    = file_get_contents($gen_url);
        $gen_data    = json_decode($gen_data, true);
        $user_gender = $gen_data['gender'];
        return $user_gender;
    }
    
    public function send_reaction($user, $pass, $token, $r_male, $r_female, $r_page, $max_status, $ignore_ids)
    {
        $get_post = 'https://graph.facebook.com/me/home?fields=id,from&limit=' . $max_status . '&access_token=' . $token;
        $get_post = file_get_contents($get_post);
        $get_post = json_decode($get_post, true);
        
        foreach ($get_post['data'] as $data) {
            $this->curl("https://mbasic.facebook.com/login.php?refsrc=https%3A%2F%2Fm.facebook.com%2F&login_try_number=1", "lsd=AVpI36s1&version=1&ajax=0&width=0&pxr=0&gps=0&dimensions=0&m_ts=1483804348&li=qg5xWAUZXopBIK0ABg1Dtlzt&email=$user&pass=$pass&login=Masuk");
            
            $stat_id  = $data['id'];
            $post_id  = explode("_", $stat_id);
            $r_start  = 'https://mbasic.facebook.com/reactions/picker/?ft_id=' . $post_id[1];
            $html     = $this->curl($r_start);
            $html     = str_replace('&amp;', '&', $html);
            $userid   = $post_id[0];
            $user_gen = $this->gender_check($userid, $token);
            $name     = $data['from']['name'];
            if (in_array($userid, $ignore_ids)){
                echo "Ignore user ID: $userid \n <br />";
                continue;
            }
            
            if ($user_gen == 'female') {
                $r_females  = '/ufi/reaction/?ft_ent_identifier=' . $post_id[1] . '&reaction_type=' . $r_female;
                $r_female_e = $this->fetch_value($html, $r_females, '" style="display:block">');
                $r_female_l = 'https://mbasic.facebook.com/ufi/reaction/?ft_ent_identifier=' . $post_id[1] . '&reaction_type=' . $r_female . $r_female_e;
                $this->curl($r_female_l);
                echo "Name: $name <br />";
                echo "Status ID $post_id[1] => $user_gen => reacted \n <br />";
            } else if ($user_gen == 'male') {
                $r_males  = '/ufi/reaction/?ft_ent_identifier=' . $post_id[1] . '&reaction_type=' . $r_male;
                $r_male_e = $this->fetch_value($html, $r_males, '" style="display:block">');
                $r_male_l = 'https://mbasic.facebook.com/ufi/reaction/?ft_ent_identifier=' . $post_id[1] . '&reaction_type=' . $r_male . $r_male_e;
                $this->curl($r_male_l);
                echo "Name: $name <br />";
                echo "Status ID $post_id[1] => $user_gen => reacted \n<br />";
            } else {
                $r_pages  = '/ufi/reaction/?ft_ent_identifier=' . $post_id[1] . '&reaction_type=' . $r_page;
                $r_page_e = $this->fetch_value($html, $r_pages, '" style="display:block">');
                $r_page_l = 'https://mbasic.facebook.com/ufi/reaction/?ft_ent_identifier=' . $post_id[1] . '&reaction_type=' . $r_page . $r_page_e;
                $this->curl($r_page_l);
                echo "Name: $name <br />";
                echo "Status ID $post_id[1] => page, user with no gender => reacted \n<br />";
            }
            sleep(2);
        }
        $this->curl('https://mbasic.facebook.com/logout.php');
        
        
        
    }
    
    
}