<?php

require_once('lib/fb.php');

//////////////////////////////////////////////[edit authentication here]///////////////////////////////////////////
$user		= 'username'; // facebook username
$pass 		= 'pass'; // facebook passwod
$r_male		= '3'; // reaction if user male , like = 1, love = 2, wow = 3, haha = 4, sad = 7, angry = 8, 0 if no reaction
$r_female	= '2'; // reaction if user female , like = 1, love = 2, wow = 3, haha = 4, sad = 7, angry = 8, 0 if no reaction
$r_page		= '4'; // reaction if page or user with no gender , like = 1, love = 2, wow = 3, haha = 4, sad = 7, angry = 8, 0 if no reaction
$max_status	= '10'; // maximum reacted status

//Những ID ở đây sẽ được bỏ qua khi auto [https://findmyfbid.in]
$ignore_ids	= array(
				100003880469096,//Admin J2team, Manh Tuan










); 
$token 		= 'EAA......ZD';
# Nên dùng iPhone Token [Suggest botexviet.com/login]
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

$config['cookie_file'] = 'cookie.txt';
if (!file_exists($config['cookie_file'])) {
    $fp = @fopen($config['cookie_file'], 'w');
    @fclose($fp);
}

$reaction = new Reaction();
$reaction->send_reaction($user, $pass, $token, $r_male, $r_female, $r_page, $max_status, $ignore_ids);